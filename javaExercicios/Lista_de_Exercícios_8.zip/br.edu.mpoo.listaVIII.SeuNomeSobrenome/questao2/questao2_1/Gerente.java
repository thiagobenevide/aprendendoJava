package questao2_1;

public class Gerente extends Funcionario{

	public Gerente(String cpf, String login) {
		super(cpf, login);
	}
}
