package mpooSystem.model;

public class Mensagem {

	public static final String ADMINISTRADOR_SUCESS = "Administrador validado com sucesso";
	public static final String ADMINISTRADOR_ERROR = "Administrador inválido";
	public static final String USUARIO_LOGIN_SUCESS = "Usuário logado com sucesso";
	public static final String USUARIO_LOGIN_ERROR = "Usuário inválido";
	public static final String USUARIO_SUCESS = "Usuario adicionado com sucesso";
	public static final String USUARIO_ERROR = "Erro ao adicionar usuário";
	
}
