package mpooSystem.view;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

import mpooSystem.util.SpringUtilities;

public class LoginView extends JFrame{
	JLabel loginLabel, senhaLabel;
	JTextField loginField, senhaField;
	JButton  entrarButton, sairButton;
	JPanel panelPrincipal, panelButton;
	
	
	public LoginView() {
		
		setSize(400, 600);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE); 
		setLayout(new BorderLayout());
		
		
		panelPrincipal = new JPanel(new SpringLayout());
		
		loginLabel = new JLabel("Login: ");
		loginField = new JTextField();
		loginField.setColumns(10);
		
		senhaLabel = new JLabel("Senha: ");
		senhaField = new JTextField();
		senhaField.setColumns(10);
		
		
		panelPrincipal.add(loginLabel);
		panelPrincipal.add(loginField);
		panelPrincipal.add(senhaLabel);
		panelPrincipal.add(loginField);
		
		
		SpringUtilities.makeCompactGrid(panelPrincipal,3 , 2, 6, 6, 6, 6);
		
		add(panelPrincipal, BorderLayout.CENTER);
	}
	
	
	
	
	
}
