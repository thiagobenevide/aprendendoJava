package mpooSystem.controller;

public class CadastrarController {

}
