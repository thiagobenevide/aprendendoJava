package mpooSystem.app;

import mpooSystem.model.BaseDados;

public class App {
	public static void main(String[] args) {
		BaseDados.createBase();
		
		
	}
}
