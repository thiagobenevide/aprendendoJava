package concorrencia;

public class Bloqueio {
	public static boolean bloqueio=false;
}
