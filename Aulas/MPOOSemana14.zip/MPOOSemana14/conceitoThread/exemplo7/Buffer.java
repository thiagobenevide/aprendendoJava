package exemplo7;

public interface Buffer {
	public void set(int value);
	public int get();
}
