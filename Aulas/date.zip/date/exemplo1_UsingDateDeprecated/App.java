package exemplo1_UsingDateDeprecated;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class App {
	public static void main(String[] args) {
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		
		/*
		 * Prezado aluno: 
		 * 
		 * Considerar a data em que a aplica��o for exeutada.
		 * Por exemplo, esta aplica��o est� sendo executada em 24/11/2021 
		 */

		//Option1
		Calendar cal = Calendar.getInstance();
		cal.set(2021, Calendar.NOVEMBER, 24, 23, 59, 59);
		usuarios.add(new Usuario(cal.getTime()));
		
		//Option2
		Date date;
		date = Calendar.getInstance().getTime();
		usuarios.add(new Usuario(date));

		//Option3 Deprecated
		usuarios.add(new Usuario(new Date(2021, 11, 24)));
		
		System.out.println("Method Solution1Option1and2");
		System.out.println(VerificarAniversario.isAniversarioSolution1Option1and2(usuarios.get(0)));
		System.out.println(VerificarAniversario.isAniversarioSolution1Option1and2(usuarios.get(1)));

		System.out.println("Method Solution1Option3");
		System.out.println(VerificarAniversario.isAniversarioSolution1Option3(usuarios.get(2)));
		
		System.out.println("Method Solution2Option1and2");
		System.out.println(VerificarAniversario.isAniversarioSolution2Option1and2(usuarios.get(0)));
		System.out.println(VerificarAniversario.isAniversarioSolution2Option1and2(usuarios.get(1)));

		System.out.println("Method Solution2Option3");
		System.out.println(VerificarAniversario.isAniversarioSolution2Option3(usuarios.get(2)));
	}
}