package exemplo1_UsingDateDeprecated;

import java.util.Date;

public class Usuario {
	Date dataNascimento;
	
	public Usuario(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}}