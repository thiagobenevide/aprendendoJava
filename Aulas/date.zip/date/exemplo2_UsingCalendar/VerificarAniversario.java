package exemplo2_UsingCalendar;

import java.time.LocalDateTime;
import java.util.Calendar;

public class VerificarAniversario {
	public static boolean isAniversarioSolution1(Usuario usuario){

		/*Observa��o: 
		 * Para Calendar:
		 *    Calendar.JANUARY = 0; Calendar.FEBRUARY = 1, etc...
		 * 
		 * Para LocalDateTime.now().getMonthValue():
		 *     JANUARY=1, FEBRUARY=2, etc...
		 */
		
		if (usuario.getDataNascimento().get(Calendar.DAY_OF_MONTH)==LocalDateTime.now().getDayOfMonth()
			&&
			(usuario.getDataNascimento().get(Calendar.MONTH)+1)==LocalDateTime.now().getMonthValue()
			)
			return true;
		else
			return false;
	}

	public static boolean isAniversarioSolution2(Usuario usuario){
		int diaUsuario, mesUsuario;
		int diaAtual, mesAtual;
		
		diaUsuario = usuario.getDataNascimento().get(Calendar.DAY_OF_MONTH);
		mesUsuario = usuario.getDataNascimento().get(Calendar.MONTH);

		diaAtual = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		mesAtual = Calendar.getInstance().get(Calendar.MONTH);
		
		if (diaUsuario==diaAtual && mesUsuario==mesAtual)
			return true;
		else return false;
	}
}