package exemplo2_UsingCalendar;

import java.util.Calendar;

public class Usuario {
	private Calendar dataNascimento;

	public Usuario(Calendar dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public Calendar getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Calendar dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
}