package exemplo2_UsingCalendar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class App {
	public static void main(String[] args) {
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		
		/*
		 * Prezado aluno: 
		 * 
		 * Considerar a data em que a aplica��o for exeutada.
		 * Por exemplo, esta aplica��o est� sendo executada em 24/11/2021 
		 */

		//Option1
		Calendar cal = Calendar.getInstance();
		cal.set(2021, Calendar.NOVEMBER, 24, 23, 59, 59);
		usuarios.add(new Usuario(cal));
		
//		//Option2 - "Uso de Date n�o permitido"
//		Date date;
//		date = Calendar.getInstance().getTime();
//		usuarios.add(new Usuario(date));

		//Option3 Deprecated - "Uso de Date n�o permitido"
//		usuarios.add(new Usuario(new Date(2021, 11, 24)));
		
		System.out.println("Method Solution1");
		for(Usuario usuario: usuarios)
			System.out.println(VerificarAniversario.isAniversarioSolution1(usuario));
		
		System.out.println("Method Solution2");
		for(Usuario usuario: usuarios)
			System.out.println(VerificarAniversario.isAniversarioSolution2(usuario));
	}
}