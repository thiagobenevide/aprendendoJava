package sobreescrita_caso2;

//caso 2:
public abstract class SuperClass extends SuperSuperClass{ }
