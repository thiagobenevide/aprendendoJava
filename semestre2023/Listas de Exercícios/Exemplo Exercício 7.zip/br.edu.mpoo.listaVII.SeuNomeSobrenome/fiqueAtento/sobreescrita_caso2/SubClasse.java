package sobreescrita_caso2;

public class SubClasse extends SuperClass {
	@Override
	public void metodo() {
		// corpo do m�todo
	}
}