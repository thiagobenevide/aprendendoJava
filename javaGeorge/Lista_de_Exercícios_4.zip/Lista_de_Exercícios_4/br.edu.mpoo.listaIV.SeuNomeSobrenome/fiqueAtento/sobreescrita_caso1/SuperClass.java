package sobreescrita_caso1;

//caso 1:
public abstract class SuperClass extends SuperSuperClass{
	@Override
	public void metodo() {
		// corpo do m�todo
	}

}
