package sobreescrita_caso1;

public abstract class SuperSuperClass {
	public abstract void metodo();
}
