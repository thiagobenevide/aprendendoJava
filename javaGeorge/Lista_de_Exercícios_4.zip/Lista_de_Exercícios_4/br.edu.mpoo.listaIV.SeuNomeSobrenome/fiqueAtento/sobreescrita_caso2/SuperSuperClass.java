package sobreescrita_caso2;

public abstract class SuperSuperClass {
	public abstract void metodo();
}
