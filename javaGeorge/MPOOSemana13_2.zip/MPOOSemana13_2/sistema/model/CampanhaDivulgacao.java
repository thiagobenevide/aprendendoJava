package model;

public class CampanhaDivulgacao {
	public static double cupomPromocional=0.1;

}
