package model;

public class SalvarDados extends Thread{
	
public void run(){
	//salvar os dados da Base em um xml ou txt
	
}	

}
