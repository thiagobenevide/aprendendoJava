package entidades;

import javax.swing.JOptionPane;

public class Mensagem {
	public static final String MENSAGEM_FALHA_RELACAO_PRODUTO_CLIENTE="N�o foi poss�vel inidicar um produto";
	//frase o que dizer vem no setor de rela��es p�blicas!
	
	public static String exibirMensagem(){
		return MENSAGEM_FALHA_RELACAO_PRODUTO_CLIENTE;
		
	}
}
