package model;

public class CPFException extends Exception {

}
