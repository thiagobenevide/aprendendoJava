package model;
import java.util.Random;

public class GerenciadorBrinde {
	public int valorBrinde;
		
}
