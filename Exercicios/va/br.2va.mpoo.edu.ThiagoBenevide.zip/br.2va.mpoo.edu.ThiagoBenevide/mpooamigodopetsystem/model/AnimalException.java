package model;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class AnimalException extends Exception{

	public AnimalException() {
		super();
		JOptionPane.showMessageDialog(null, "Não existe o animal disponível! Adote outro tipo de animal!", "MPOOAmigodoPet", 0, new ImageIcon("mpooamigodopet.img/icone.png"));
	}

	
	
}
