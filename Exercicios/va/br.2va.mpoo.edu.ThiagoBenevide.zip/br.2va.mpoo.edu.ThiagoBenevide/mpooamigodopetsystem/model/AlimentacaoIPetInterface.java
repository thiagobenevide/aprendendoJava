package model;

public interface AlimentacaoIPetInterface {
	
	
	public String informacaoAlimentacao();
	
	
}
