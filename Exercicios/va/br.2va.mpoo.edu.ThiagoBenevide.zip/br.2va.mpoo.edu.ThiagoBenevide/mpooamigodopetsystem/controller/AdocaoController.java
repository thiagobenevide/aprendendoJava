package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import model.BaseDados;
import model.CPFException;
import model.Proprietario;
import view.AdocaoView;
import view.IndexView;

public class AdocaoController implements ActionListener{
	AdocaoView adocaoView;
	private WindowHandler windowHandler;
	private IndexView telaIndexView;
	public AdocaoController(IndexView indexView) {
		adocaoView = new AdocaoView();
		windowHandler = new WindowHandler();
		telaIndexView = indexView;
		controller();
		
		
	}
	
	private void controller() {
		adocaoView.addWindowListener(windowHandler);
		adocaoView.getAdotarButton().addActionListener(this);
	}

	
	private class WindowHandler extends WindowAdapter{
		
		@Override
		public void windowClosing(WindowEvent e) {
			// TODO Auto-generated method stub
			super.windowClosing(e);
			adocaoView.setVisible(false);
			telaIndexView.setVisible(true);
		}
		
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String cpf = adocaoView.getCampoPanel().getNomeField().getText().replace(".", "").replace("-", "");
		String nome = adocaoView.getCampoPanel().getNomeField().getText();
		String email = adocaoView.getCampoPanel().getNomeField().getText();
		String fone = adocaoView.getCampoPanel().getNomeField().getText().replace("-", "").replace("+", "").replace("+", "");
		if(e.getSource()==adocaoView.getAdotarButton()) {
			if(BaseDados.buscarProprietario(cpf)!=null) {
				validarAnimal(cpf);
				
			}else {
				try {
					BaseDados.addProprietario(new Proprietario(nome, cpf, email, fone));
					validarAnimal(cpf);
				} catch (CPFException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}		
			}
			
			
			
			
			
			
			
		}
		
		}
		
		
	private void validarAnimal(String cpf) {
		if(adocaoView.getCampoPanel().getCachorroRadio().isSelected()) {
			if(BaseDados.buscarAnimal("cachorro")!=null) {
				BaseDados.buscarProprietario(cpf).animais.add(BaseDados.buscarAnimal("cachorro"));	
				JOptionPane.showMessageDialog(null, "Cadastro realizado com suscesso! Em breve você estará com o seu pet", "MPOOAmigodoPet", 0, new ImageIcon("mpooamigodopet.img/icone.png"));
			}
		}else if(adocaoView.getCampoPanel().getGatoRadio().isSelected()) {
			if(BaseDados.buscarAnimal("gato")!=null) {
				BaseDados.buscarProprietario(cpf).animais.add(BaseDados.buscarAnimal("gato"));	
				JOptionPane.showMessageDialog(null, "Cadastro realizado com suscesso! Em breve você estará com o seu pet", "MPOOAmigodoPet", 0, new ImageIcon("mpooamigodopet.img/icone.png"));
			}
		}else if(adocaoView.getCampoPanel().getCoelhoRadio().isSelected()) {
			if(BaseDados.buscarAnimal("coelho")!=null) {
				BaseDados.buscarProprietario(cpf).animais.add(BaseDados.buscarAnimal("coelho"));	
				JOptionPane.showMessageDialog(null, "Cadastro realizado com suscesso! Em breve você estará com o seu pet", "MPOOAmigodoPet", 0, new ImageIcon("mpooamigodopet.img/icone.png"));
			}
		}else if (adocaoView.getCampoPanel().getSemPreferenciaRadio().isSelected()) {
			if(BaseDados.buscarAnimal("sempreferencia")!=null) {
				BaseDados.buscarProprietario(cpf).animais.add(BaseDados.buscarAnimal("sempreferencia"));	
				JOptionPane.showMessageDialog(null, "Cadastro realizado com suscesso! Em breve você estará com o seu pet", "MPOOAmigodoPet", 0, new ImageIcon("mpooamigodopet.img/icone.png"));
			}
		}
	}
	

	
	
	
	
	
}
