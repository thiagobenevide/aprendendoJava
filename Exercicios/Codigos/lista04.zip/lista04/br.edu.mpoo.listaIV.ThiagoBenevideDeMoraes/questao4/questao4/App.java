package questao4;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BaseDados.createBase();
		Sistema.entrarSistema("941.860.760-30", "mariasilva@gmail.com", "123456");
		
	}

}
