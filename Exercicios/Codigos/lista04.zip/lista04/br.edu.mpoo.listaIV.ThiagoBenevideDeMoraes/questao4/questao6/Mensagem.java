package questao6;

public class Mensagem {

	public static String isMensagem() {
		String mensagem = "TESTE";
		return mensagem;
	}
	
}
