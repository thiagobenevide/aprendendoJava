package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Backup {

	private static BufferedWriter bufferedWriter;
	private static final String path = "arquivo/baseDadosBackup";
	private static BufferedReader fileBufferedReader;
	
	public static void openFile(String path) throws FileNotFoundException, IOException {
		try {
			
			File file = new File(path);
			if(!file.exists())
				file.createNewFile();
			bufferedWriter = new BufferedWriter(new FileWriter(file, true));
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void savePessoa(Usuario pessoa) {
		try {
			bufferedWriter.write(pessoa.getNome());
			bufferedWriter.newLine();
			bufferedWriter.write(pessoa.getCpf());
			bufferedWriter.newLine();
			Calendar niver = pessoa.getNiver();
			SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			bufferedWriter.write(niver.getTime().toString());
			bufferedWriter.newLine();
			bufferedWriter.write(pessoa.getLogin());
			bufferedWriter.newLine();
			bufferedWriter.write(pessoa.getLogin());
			bufferedWriter.newLine();
			bufferedWriter.write(",");
			bufferedWriter.newLine();
			bufferedWriter.flush();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void closeFile() {
		if (bufferedWriter != null)
			try {
				bufferedWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	
}
