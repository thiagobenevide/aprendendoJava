package model;

import java.time.LocalDateTime;
import java.util.Calendar;

public interface NiverManaged {

	public default boolean isNiver(Calendar niver) {
		if ((niver.get(Calendar.MONTH)+1)==LocalDateTime.now().getMonthValue())
			 return true;
			 else return false;
	}
	
}
