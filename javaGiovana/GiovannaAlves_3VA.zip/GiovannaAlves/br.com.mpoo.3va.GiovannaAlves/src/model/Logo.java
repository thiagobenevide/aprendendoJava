package model;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Logo {

	ImageIcon logo;
	
	public Logo() {
		try {
			File file = new File("img/logo.png");
			BufferedImage bufferedImage = ImageIO.read(file);
			logo = new ImageIcon(bufferedImage);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ImageIcon getLogo() {
		return logo;
	}
	
	
}
