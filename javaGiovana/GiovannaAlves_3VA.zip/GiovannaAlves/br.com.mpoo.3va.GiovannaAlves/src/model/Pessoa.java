package model;

import java.util.Calendar;

public abstract class Pessoa implements PessoaManaged {

	public String nome;
	protected String cpf;
	protected String sexo;
	private Calendar niver;
	
	public Pessoa(String nome, String cpf, String sexo, Calendar niver) {
		this.nome = nome;
		this.cpf = cpf;
		this.sexo = sexo;
		this.niver = niver;
	}
	public String getNome() {
		return nome;
	}
	public String getCpf() {
		return cpf;
	}
	public String getSexo() {
		return sexo;
	}
	public Calendar getNiver() {
		return niver;
	}
	@Override
	public String toString() {
		return "Pessoa [nome=" + nome + ", cpf=" + cpf + ", sexo=" + sexo + ", niver=" + niver + "]";
	}
	
}
