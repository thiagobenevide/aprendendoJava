package model;

public class PessoaException extends Exception {

	public PessoaException(String mensagem) {
		super(mensagem);
	}
	
}
