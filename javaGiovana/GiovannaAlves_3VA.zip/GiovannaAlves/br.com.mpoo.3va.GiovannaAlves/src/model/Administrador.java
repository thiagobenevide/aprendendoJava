package model;

import java.util.Calendar;

public class Administrador extends Usuario {

	public Administrador(String nome, String cpf, String sexo, Calendar niver, String login, String senha) {
		super(nome, cpf, sexo, niver, login, senha);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Administrador [getLogin()=" + getLogin() + ", getNome()=" + getNome() + ", getCpf()=" + getCpf()
				+ ", getSexo()=" + getSexo() + ", getNiver()=" + getNiver() + "]";
	}

	
	
}
