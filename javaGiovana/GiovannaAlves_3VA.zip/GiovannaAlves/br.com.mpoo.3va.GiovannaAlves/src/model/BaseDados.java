package model;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class BaseDados {

	private static ArrayList<Pessoa> pessoas;
	
	public static void createBase() {
		pessoas = new ArrayList<Pessoa>();
		inicializarBase();
		uploadBase(null);
	}
	
	public static void inicializarBase() {
		
	}
	
	private static void uploadBase(String path) {
		
	}
	
	private static Pessoa buscarPessoa(String cpf) {
		for (Pessoa p : pessoas) {
			if (p.getCpf().equals(cpf)) {
				return p;
			}
		}
		return null;
	}
	
	public static boolean isPessoa(Pessoa pessoa) throws PessoaException {
		try {
			if (pessoa == null) {
				throw new PessoaException("Usu�rio null");
			}
			
			if (buscarPessoa(pessoa.getCpf()) != null) {
				throw new PessoaException("Usu�rio j� existe");
			}
			
			if (buscarPessoa(pessoa.getCpf()) == null) {
				throw new PessoaException("Usu�rio n�o existe");
			}
			
		} catch (PessoaException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static boolean adicionarPessoa(Pessoa pessoa) throws PessoaException {
	
		try {
			if (pessoa == null) {
				throw new PessoaException("Usu�rio null");
			}
			
			if (buscarPessoa(pessoa.getCpf()) == null) {
				pessoas.add(pessoa);
				Backup.savePessoa((Usuario)pessoa);
				throw new PessoaException("Adicionado com sucesso!");
			}
			
			if (buscarPessoa(pessoa.getCpf()) != null) {
				throw new PessoaException("Usu�rio j� existe");
			}
			
		} catch (PessoaException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static boolean removerPessoa(Pessoa pessoa) throws PessoaException {
		try {
			if (pessoa == null) {
				throw new PessoaException("Usu�rio null");
			}
			
			if (buscarPessoa(pessoa.getCpf()) == null) {
				throw new PessoaException("Usu�rio n�o existe");
			}
			
			if (buscarPessoa(pessoa.getCpf()) != null) {
				pessoas.remove(buscarPessoa(pessoa.getCpf()));
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static ArrayList<String> listPessoas(){
		ArrayList<String> lista = new ArrayList<String>();
		
		for (Pessoa p : pessoas) {
			lista.add(p.getNome().toString());
		}
		
		return lista;
	}
	
	
}
