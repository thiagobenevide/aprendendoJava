package model;

import java.util.Calendar;

public class Usuario extends Pessoa {

	private String login;
	private String senha;
	
	public Usuario(String nome, String cpf, String sexo, Calendar niver, String login, String senha) {
		super(nome, cpf, sexo, niver);
		this.login = login;
		this.senha = senha;
	}

	public String getLogin() {
		return login;
	}

	@Override
	public String toString() {
		return "Usuario [login=" + login + ", getNome()=" + getNome() + ", getCpf()=" + getCpf() + ", getSexo()="
				+ getSexo() + ", getNiver()=" + getNiver() + "]";
	}
	
}
