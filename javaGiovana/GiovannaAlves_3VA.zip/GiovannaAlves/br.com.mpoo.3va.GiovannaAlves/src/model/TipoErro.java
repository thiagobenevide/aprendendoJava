package model;

public class TipoErro {

	public final String EXISTE_USUARIO = "Usu�rio j� existe";
	public final String NULL_USUARIO = "Usu�rio null";
	public final String USUARIO_INVALIDO = "Dados de usu�rio inv�lido";
	public final String NAO_EXISTE_USUARIO = "Usu�rio n�o existe";
	
	public String getEXISTE_USUARIO() {
		return EXISTE_USUARIO;
	}
	public String getNULL_USUARIO() {
		return NULL_USUARIO;
	}
	public String getUSUARIO_INVALIDO() {
		return USUARIO_INVALIDO;
	}
	public String getNAO_EXISTE_USUARIO() {
		return NAO_EXISTE_USUARIO;
	}

	
}
