package model;

public interface PessoaManaged extends NiverManaged, CPFManaged {
	
}
