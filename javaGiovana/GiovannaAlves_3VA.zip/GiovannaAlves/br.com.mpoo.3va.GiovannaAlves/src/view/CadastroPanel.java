package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class CadastroPanel extends JPanel {

	JLabel logoLabel, tituloLabel;
	JTextField nomeField, cpfField, niverField, loginField;
	JPasswordField senhaField;
	JButton adicionarButton;
	JRadioButton masculinoButton, femininoButton;
	
	public CadastroPanel(ImageIcon logo) {
		setLayout(new BorderLayout());
		
		JPanel principalPanel = new JPanel(new SpringLayout());
		
		logoLabel = new JLabel(logo);
		
		
		tituloLabel = new JLabel("Dados Pessoais");
		tituloLabel.setFont(new Font("", Font.BOLD, 15));
		
		nomeField = new JTextField("Seu nome", 10);
		nomeField.setForeground(Color.LIGHT_GRAY);

		cpfField = new JTextField("CPF", 10);
		cpfField.setForeground(Color.LIGHT_GRAY);
		
		ButtonGroup buttonGroup = new ButtonGroup();
		
		masculinoButton = new JRadioButton("Ele", true);
		femininoButton = new JRadioButton("Ela");
		
		buttonGroup.add(masculinoButton);
		buttonGroup.add(femininoButton);
		
		JPanel panelRadios = new JPanel(new SpringLayout());
		panelRadios.add(masculinoButton);
		panelRadios.add(femininoButton);

		util.SpringUtilities.makeCompactGrid(panelRadios, 1, 2, 6, 6, 6, 6);
		
		niverField = new JTextField("dd/mm/aaaa", 10);
		niverField.setForeground(Color.LIGHT_GRAY);

		loginField = new JTextField("Login", 10);
		loginField.setForeground(Color.LIGHT_GRAY);

		senhaField = new JPasswordField(10);
		
		JPanel panelButton = new JPanel();
		
		adicionarButton = new JButton("Adicionar");
		adicionarButton.setSize(100,100);
		panelButton.setSize(100,100);
		
		adicionarButton.setEnabled(false);
		
		panelButton.add(adicionarButton);
		
		principalPanel.add(logoLabel);
		
		principalPanel.add(tituloLabel);

		principalPanel.add(nomeField);
		
		principalPanel.add(cpfField);
		
		principalPanel.add(panelRadios);
		
		principalPanel.add(niverField);
		
		principalPanel.add(loginField);
		
		principalPanel.add(senhaField);
		
		principalPanel.add(panelButton);
		
		util.SpringUtilities.makeCompactGrid(principalPanel, 9, 1, 6, 6, 6, 6);
		
		add(principalPanel, BorderLayout.CENTER);
		
		setVisible(false);
	}

	public JLabel getLogoLabel() {
		return logoLabel;
	}

	public JLabel getTituloLabel() {
		return tituloLabel;
	}

	public JTextField getNomeField() {
		return nomeField;
	}

	public JTextField getCpfField() {
		return cpfField;
	}

	public JTextField getNiverField() {
		return niverField;
	}

	public JTextField getLoginField() {
		return loginField;
	}

	public JPasswordField getSenhaField() {
		return senhaField;
	}

	public JButton getAdicionarButton() {
		return adicionarButton;
	}

	public JRadioButton getMasculinoButton() {
		return masculinoButton;
	}

	public JRadioButton getFemininoButton() {
		return femininoButton;
	}

}
