package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.security.Principal;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class SistemaGUI extends JFrame {

	private JMenuBar menuBar;
	private JMenu logarJMenu, gerenciarJMenu, relatorioJMenu, sairJMenu, usuarioJMenu;
	private JMenuItem adicionarMenuItem, removerMenuItem, exibirMenuItem;
	LoginPanel loginPanel;
	CadastroPanel cadastroPanel;
	JPanel principalPanel;
	
	public SistemaGUI(ImageIcon icone, ImageIcon logo) {
		super("MPOO System");
		
		setSize(400,400);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		menuBar = new JMenuBar();
		
		logarJMenu = new JMenu("Logar");
		
		gerenciarJMenu = new JMenu("Gerenciar");
		
		relatorioJMenu = new JMenu("Relat�rio");
		
		sairJMenu = new JMenu("Sair");
		
		usuarioJMenu = new JMenu("Usu�rio");
		
		gerenciarJMenu.add(usuarioJMenu);
		
		adicionarMenuItem = new JMenuItem("Adicionar");
		
		adicionarMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.ALT_MASK));
		
		removerMenuItem = new JMenuItem("Remover");
		
		exibirMenuItem = new JMenuItem("Exibir");
		
		usuarioJMenu.add(adicionarMenuItem);
		usuarioJMenu.add(removerMenuItem);
		usuarioJMenu.add(exibirMenuItem);
		
		menuBar.add(logarJMenu);
		menuBar.add(gerenciarJMenu);
		menuBar.add(relatorioJMenu);
		menuBar.add(sairJMenu);
		
		setJMenuBar(menuBar);
		
		setIconImage(icone.getImage());
		
		principalPanel = new JPanel();
		principalPanel.setVisible(false);
		
		cadastroPanel = new CadastroPanel(logo);
		
		loginPanel = new LoginPanel(logo);
				
		setVisible(false);
	}

	public JMenu getLogarJMenu() {
		return logarJMenu;
	}

	public JMenu getGerenciarJMenu() {
		return gerenciarJMenu;
	}

	public JMenu getRelatorioJMenu() {
		return relatorioJMenu;
	}

	public JMenu getSairJMenu() {
		return sairJMenu;
	}

	public JMenu getUsuarioJMenu() {
		return usuarioJMenu;
	}

	public JMenuItem getAdicionarMenuItem() {
		return adicionarMenuItem;
	}

	public JMenuItem getRemoverMenuItem() {
		return removerMenuItem;
	}

	public JMenuItem getExibirMenuItem() {
		return exibirMenuItem;
	}

	public LoginPanel getLoginPanel() {
		return loginPanel;
	}

	public CadastroPanel getCadastroPanel() {
		return cadastroPanel;
	}

	public JPanel getPrincipalPanel() {
		return principalPanel;
	}

	public void setPrincipalPanel(JPanel principalPanel) {
		this.principalPanel = principalPanel;
	}
	
}
