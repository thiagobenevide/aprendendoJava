package view;

import javax.swing.JOptionPane;

public class MensagemGUI {

	public static void exibirMensagem(String mensagem) {
		JOptionPane.showMessageDialog(null, mensagem);
	}
	
}
