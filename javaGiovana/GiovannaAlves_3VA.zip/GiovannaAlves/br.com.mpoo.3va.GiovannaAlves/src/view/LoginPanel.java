package view;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class LoginPanel extends JPanel {

	JLabel logoLabel;
	JTextField loginField;
	JPasswordField senhaField;
	JButton entrarButton;
	
	public LoginPanel(ImageIcon logo) {
		setLayout(new BorderLayout());
		
		JPanel panelPrincipal = new JPanel(new SpringLayout());
		
		logoLabel = new JLabel(logo);
		
		loginField = new JTextField(10);
		loginField.setText("Login");
		loginField.setForeground(Color.LIGHT_GRAY);
		
		senhaField = new JPasswordField(10);

		JPanel panelButton = new JPanel();
		entrarButton = new JButton("Entrar");
		entrarButton.setSize(70, 70);
		panelButton.setSize(70, 70);
		panelButton.add(entrarButton);
		
		entrarButton.setEnabled(false);
		
		panelPrincipal.add(logoLabel);
		panelPrincipal.add(loginField);
		panelPrincipal.add(senhaField);
		panelPrincipal.add(entrarButton);
		
		util.SpringUtilities.makeCompactGrid(panelPrincipal, 4, 1, 6, 6, 6, 6);
		
		add(panelPrincipal, BorderLayout.CENTER);
		
		setVisible(false);
		
	}

	public JLabel getLogoLabel() {
		return logoLabel;
	}

	public JTextField getLoginField() {
		return loginField;
	}

	public JPasswordField getSenhaField() {
		return senhaField;
	}

	public JButton getEntrarButton() {
		return entrarButton;
	}
	
}
