package app;

import controller.MpooSystemController;
import model.BaseDados;
import model.Icone;
import model.Logo;
import view.SistemaGUI;

public class App extends Thread {

	public static void main(String[] args) {

		BaseDados.createBase();
		
//		Icone icone = new Icone();
//		Logo logo = new Logo();
//		
//		new SistemaGUI(icone.getIcone(), logo.getLogo());

		new MpooSystemController();
		
	}

	@Override
	public void run() {
		
		try {
			sleep(600000);
						
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		
	}

	
}
