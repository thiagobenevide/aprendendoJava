package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import model.BaseDados;
import model.Icone;
import model.Logo;
import model.PessoaException;
import model.Usuario;
import view.MensagemGUI;
import view.SistemaGUI;

public class MpooSystemController implements CaretListener {
	
	SistemaGUI sistemaGUI;
	Icone icone;
	Logo logo;
	MouseHandler mouseHandler;
	FormularioHandler formularioHandler;
	FocusHandler focusHandler;
	private boolean status;
	
	public MpooSystemController() {
		icone = new Icone();
		logo = new Logo();
		
		mouseHandler = new MouseHandler();
		formularioHandler = new FormularioHandler();
		focusHandler = new FocusHandler();
		
		sistemaGUI = new SistemaGUI(icone.getIcone(), logo.getLogo());
		sistemaGUI.setVisible(true);
		
		control();
	}
	
	private void control() {
		// LOGAR
		sistemaGUI.getLogarJMenu().addMouseListener(mouseHandler);
		// GERENCIAR LIBERA OS CAMPOS SE O USU�RIO TIVER LOGADO J�
		sistemaGUI.getAdicionarMenuItem().addActionListener(formularioHandler);
		// RELAT�RIO - EXIBE OS NOMES DOS USU�RIOS CADASTROS NO JFRAME
		sistemaGUI.getRelatorioJMenu().addMouseListener(mouseHandler);
		// SAIR
		sistemaGUI.getSairJMenu().addMouseListener(mouseHandler);
		// TRATAMENTO INTERNO PRIVADO
		sistemaGUI.getLoginPanel().getEntrarButton().addActionListener(formularioHandler);
		sistemaGUI.getCadastroPanel().getAdicionarButton().addActionListener(formularioHandler);
		//FOCUS LOGIN
		sistemaGUI.getLoginPanel().getLoginField().addFocusListener(focusHandler);
		sistemaGUI.getLoginPanel().getSenhaField().addFocusListener(focusHandler);
		//FOCUS CADASTRO
		sistemaGUI.getCadastroPanel().getNomeField().addFocusListener(focusHandler);
		sistemaGUI.getCadastroPanel().getCpfField().addFocusListener(focusHandler);
		sistemaGUI.getCadastroPanel().getNiverField().addFocusListener(focusHandler);
		sistemaGUI.getCadastroPanel().getLoginField().addFocusListener(focusHandler);
		sistemaGUI.getCadastroPanel().getSenhaField().addFocusListener(focusHandler);
		//CARET LOGIN
		sistemaGUI.getLoginPanel().getLoginField().addCaretListener(this);
		sistemaGUI.getLoginPanel().getSenhaField().addCaretListener(this);
		//CARET CADASTRO
		sistemaGUI.getCadastroPanel().getNomeField().addCaretListener(this);
		sistemaGUI.getCadastroPanel().getCpfField().addCaretListener(this);
		sistemaGUI.getCadastroPanel().getNiverField().addCaretListener(this);
		sistemaGUI.getCadastroPanel().getLoginField().addCaretListener(this);
		sistemaGUI.getCadastroPanel().getSenhaField().addCaretListener(this);
		// KEY
		sistemaGUI.getSairJMenu().addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {}
			
			@Override
			public void keyReleased(KeyEvent e) {}
			
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
					System.exit(0);
				}
			}
		});
	}
	
	private void adicionar(String sexo) {
		
		String strData = sistemaGUI.getCadastroPanel().getNiverField().getText();
		
		String[] resultadoData = strData.split("/");
		
		int dia = Integer.parseInt(resultadoData[0]);
		int mes = Integer.parseInt(resultadoData[1]);
		int ano = Integer.parseInt(resultadoData[2]);

		Calendar c = Calendar.getInstance();
		c.set(ano, mes, dia);
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");

		
		try {
			BaseDados.adicionarPessoa(new Usuario(sistemaGUI.getCadastroPanel().getNomeField().getText(),
					sistemaGUI.getCadastroPanel().getCpfField().getText(),
					sexo,
					c,
					sistemaGUI.getCadastroPanel().getLoginField().getText(),
					sistemaGUI.getCadastroPanel().getSenhaField().getText()));
				new MensagemGUI().exibirMensagem("Adicionado com sucesso!");
		} catch (PessoaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), null, JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private void update(JPanel panel) {
		
		if (sistemaGUI.getPrincipalPanel() != null) {
			
			sistemaGUI.getPrincipalPanel().setVisible(false);
			sistemaGUI.setPrincipalPanel(null);
			System.gc();
			sistemaGUI.setPrincipalPanel(panel);
			sistemaGUI.add(sistemaGUI.getPrincipalPanel(), BorderLayout.CENTER);
			sistemaGUI.getPrincipalPanel().setVisible(true);
		}
		
		sistemaGUI.setPrincipalPanel(panel);
		sistemaGUI.add(sistemaGUI.getPrincipalPanel(), BorderLayout.CENTER);
		sistemaGUI.getPrincipalPanel().setVisible(true);
	}
	
private class MouseHandler extends MouseAdapter {
	@Override
	public void mouseClicked(MouseEvent e) {
		
		if (e.getSource() == sistemaGUI.getLogarJMenu()) {
			update(sistemaGUI.getLoginPanel());
		}
		
		else if (e.getSource() == sistemaGUI.getAdicionarMenuItem()) {
			if (status == true) {
			update(sistemaGUI.getCadastroPanel());
			}
		
			new MensagemGUI().exibirMensagem("� necess�rio logar primeiro");
		}
		
		if (e.getSource() == sistemaGUI.getRelatorioJMenu()) {
			sistemaGUI.getPrincipalPanel().setVisible(false);
			sistemaGUI.setPrincipalPanel(null);
			// jogar na tela agora
			sistemaGUI.getPrincipalPanel().setVisible(true);
		}
		
		if (e.getSource() == sistemaGUI.getSairJMenu()) {
			System.exit(0);
		}
		
	}	
}

private class FormularioHandler implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == sistemaGUI.getAdicionarMenuItem()) {
			if (status == true) {
				update(sistemaGUI.getCadastroPanel());
			}
			if (status == false) {
				new MensagemGUI().exibirMensagem("� necess�rio logar primeiro");
			}
		}
		if (e.getSource() == sistemaGUI.getLoginPanel().getEntrarButton()) {
			status = true;
			
		}
		
		if (e.getSource() == sistemaGUI.getCadastroPanel().getAdicionarButton()) {
			
			if (sistemaGUI.getCadastroPanel().getMasculinoButton().isSelected()) {
				adicionar("masculino");
			}
			
			else if (sistemaGUI.getCadastroPanel().getFemininoButton().isSelected()) {
				adicionar("feminino");
			}
		}
		
	}

}

private class FocusHandler extends FocusAdapter {
	@Override
	public void focusGained(FocusEvent e) {
		
		if (e.getSource() == sistemaGUI.getLoginPanel().getLoginField()) {
			sistemaGUI.getLoginPanel().getLoginField().setText("");
			sistemaGUI.getLoginPanel().getLoginField().setForeground(Color.BLACK);
		}
		
		// CADASTRO
		
		if (e.getSource() == sistemaGUI.getCadastroPanel().getNomeField()) {
			sistemaGUI.getCadastroPanel().getNomeField().setText("");
			sistemaGUI.getCadastroPanel().getNomeField().setForeground(Color.BLACK);
		}
		
		if (e.getSource() == sistemaGUI.getCadastroPanel().getCpfField()) {
			sistemaGUI.getCadastroPanel().getCpfField().setText("");
			sistemaGUI.getCadastroPanel().getCpfField().setForeground(Color.BLACK);
		}

		if (e.getSource() == sistemaGUI.getCadastroPanel().getNiverField()) {
			sistemaGUI.getCadastroPanel().getNiverField().setText("");
			sistemaGUI.getCadastroPanel().getNiverField().setForeground(Color.BLACK);
		}

		if (e.getSource() == sistemaGUI.getCadastroPanel().getLoginField()) {
			sistemaGUI.getCadastroPanel().getLoginField().setText("");
			sistemaGUI.getCadastroPanel().getLoginField().setForeground(Color.BLACK);
		}
		
	}

	@Override
	public void focusLost(FocusEvent e) {

		if (sistemaGUI.getLoginPanel().getLoginField().getText().equals("")) {
			sistemaGUI.getLoginPanel().getLoginField().setText("Login");
			sistemaGUI.getLoginPanel().getLoginField().setForeground(Color.LIGHT_GRAY);
		}
		
		// CADASTRO
		
		if (sistemaGUI.getCadastroPanel().getNomeField().getText().equals("")) {
			sistemaGUI.getCadastroPanel().getNomeField().setText("Seu nome");
			sistemaGUI.getCadastroPanel().getNomeField().setForeground(Color.LIGHT_GRAY);
		}
		
		if (sistemaGUI.getCadastroPanel().getCpfField().getText().equals("")) {
			sistemaGUI.getCadastroPanel().getCpfField().setText("CPF");
			sistemaGUI.getCadastroPanel().getCpfField().setForeground(Color.LIGHT_GRAY);
		}

		if (sistemaGUI.getCadastroPanel().getNiverField().getText().equals("")) {
			sistemaGUI.getCadastroPanel().getNiverField().setText("dd/mm/aaaa");
			sistemaGUI.getCadastroPanel().getNiverField().setForeground(Color.LIGHT_GRAY);
		}

		if (sistemaGUI.getCadastroPanel().getLoginField().getText().equals("")) {
			sistemaGUI.getCadastroPanel().getLoginField().setText("Login");
			sistemaGUI.getCadastroPanel().getLoginField().setForeground(Color.LIGHT_GRAY);
		}
				
	}

}

@Override
public void caretUpdate(CaretEvent e) {
	
	if (sistemaGUI.getLoginPanel().getLoginField().getText().length() != 0 &&
			!sistemaGUI.getLoginPanel().getLoginField().getText().contains("Login") &&
			sistemaGUI.getLoginPanel().getSenhaField().getText().length() != 0) {
		sistemaGUI.getLoginPanel().getEntrarButton().setEnabled(true);
	}
	
	else if (sistemaGUI.getCadastroPanel().getNomeField().getText().length() != 0 &&
			!sistemaGUI.getCadastroPanel().getNomeField().getText().contains("Seu nome") &&
			sistemaGUI.getCadastroPanel().getCpfField().getText().length() != 0 &&
			!sistemaGUI.getCadastroPanel().getCpfField().getText().contains("CPF") &&
			sistemaGUI.getCadastroPanel().getNiverField().getText().length() != 0 &&
			!sistemaGUI.getCadastroPanel().getNiverField().getText().contains("dd/mm/aaaa") &&
			sistemaGUI.getCadastroPanel().getLoginField().getText().length() != 0 &&
			!sistemaGUI.getCadastroPanel().getLoginField().getText().contains("Login") &&
			sistemaGUI.getCadastroPanel().getSenhaField().getText().length() != 0) {
		sistemaGUI.getCadastroPanel().getAdicionarButton().setEnabled(true);
	}
	
	else {
		sistemaGUI.getCadastroPanel().getAdicionarButton().setEnabled(false);
		sistemaGUI.getLoginPanel().getEntrarButton().setEnabled(false);
	}
}

}
