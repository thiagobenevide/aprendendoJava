package campanhaVenda;

public class App {
	public static void main(String[] args) {
		Campanha campanhaDivulgacao = new Divulgacao();
		Campanha campanhaVerao = new Verao();
		
		System.out.println(campanhaDivulgacao);
		System.out.println(campanhaVerao);
	}
}