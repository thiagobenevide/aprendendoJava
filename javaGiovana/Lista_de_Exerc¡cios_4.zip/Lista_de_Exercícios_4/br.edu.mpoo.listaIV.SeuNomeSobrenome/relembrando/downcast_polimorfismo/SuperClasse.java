package downcast_polimorfismo;

//SuperClasse.java
public class SuperClasse {
	private int atr_SuperClasse;

	public int getAtr_SuperClasse() { return atr_SuperClasse;	}

	public void setAtr_SuperClasse(int atr_SuperClasse) {
		this.atr_SuperClasse = atr_SuperClasse;
	}
	
	@Override
	public String toString() {
		return "[atr_SuperClasse=" + atr_SuperClasse + "]";
	}
}