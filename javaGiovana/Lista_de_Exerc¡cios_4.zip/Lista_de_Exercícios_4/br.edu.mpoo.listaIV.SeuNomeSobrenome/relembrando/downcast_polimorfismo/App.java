package downcast_polimorfismo;

import java.util.ArrayList;

public class App {
	public static void main(String[] args) {

		// Usando ArrayList:
		ArrayList<SuperClasse> superClasses = new ArrayList<SuperClasse>();
		superClasses.add(new SuperClasse());
		superClasses.add(new SubClasse());

		// Usando foreach e instanceof:
		int cont=0;
		for (SuperClasse superClasseCurrente:superClasses){
			System.out.println("Element: [" + cont + "]");
			if(superClasseCurrente instanceof SuperClasse)
				System.out.println(superClasseCurrente.getAtr_SuperClasse());
			if(superClasseCurrente instanceof SubClasse) 
				System.out.println(((SubClasse)superClasseCurrente).getAtr_SubClasse());
			cont++;
		}

		// Usando vincula��o din�mica com toString():
		cont=0;
		for (SuperClasse superClasseCurrente:superClasses){
			System.out.println("Element: [" + cont + "]");
			System.out.println(superClasseCurrente);//mesmo que: System.out.println(superClasseCurrente.toString());
			cont++;
		}
	}
}
