package sobreescrita_caso1;

public class SubClasse extends SuperClass { }