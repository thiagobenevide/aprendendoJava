package sistemaPetShop;

public interface Alimentacao {

	public abstract String informacaoAlimentacao();
	
}
