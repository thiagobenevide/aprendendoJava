package app;

import gui.TelaSemTratamentoEvento;
import gui.TelaTratamentoEventoPropiaClasse;

public class App {
public static void main(String[] args) {
	new TelaTratamentoEventoPropiaClasse();
}
}
