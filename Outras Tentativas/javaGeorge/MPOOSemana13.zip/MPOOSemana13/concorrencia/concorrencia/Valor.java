package concorrencia;

public class Valor extends Thread{
	public int numero;
}
