package conceitoHeranca;

public class C extends B{

	public C(int atr, int atr2) {
		super(atr, atr2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void metodoAbstrato2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void metodoAbstrato() {
		// TODO Auto-generated method stub
		
	}

}
