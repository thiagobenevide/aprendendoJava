package app;

public class Teste {

	int a;

	/**
	 * Texto
	 * @param a
	 */
	public Teste(int a) {
		super();
		this.a = a;
	}

	/**
	 * @return the a
	 */
	public int getA() {
		return a;
	}

	/**
	 * @param a the a to set
	 */
	public void setA(int a) {
		this.a = a;
	}
	
	
	public static void main(String[] args) {
		new Teste(2).ge
	}
	
	
}
