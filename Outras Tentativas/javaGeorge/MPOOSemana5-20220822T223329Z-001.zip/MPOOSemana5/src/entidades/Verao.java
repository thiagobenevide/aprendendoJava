package entidades;

public class Verao extends Campanha{

	public Verao(String nome, int ano, int numero) {
		super(nome, ano, numero);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Produto indicarProduto(Cliente cliente) {
		// corpo do metodo
		return null;
	}
	

}
