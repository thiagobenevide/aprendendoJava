package entidades;

public class BlackFriday extends Liquida {

	public BlackFriday(String nome, int ano, int numero) {
		super(nome, ano, numero);
		// TODO Auto-generated constructor stub
	}

	//Cuidado na regra de sobreescrita (@Override) de m�todos abstratos
//	@Override
//	public Produto indicarProduto(Cliente cliente) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
