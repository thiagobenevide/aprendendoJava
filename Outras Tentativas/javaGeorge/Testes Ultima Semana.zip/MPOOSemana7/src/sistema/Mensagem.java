package sistema;

public class Mensagem {
	private static final String MENSAGEM_FALHA_RELACAO_PRODUTO_CLIENTE = "Não foi possível indicar produto";
	
	public static String getMensagemFalhaRelacaoProdutoCliente() {
		return MENSAGEM_FALHA_RELACAO_PRODUTO_CLIENTE;
	}
	
}
