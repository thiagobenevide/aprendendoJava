package sistema;

public class Liquida {

}
