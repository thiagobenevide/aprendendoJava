package sistema;

public class Verao extends Campanha{

	public Verao(String nome, int ano, int numero) {
		super(nome, ano, numero);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Produto indicarProduto(Cliente cliente) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
